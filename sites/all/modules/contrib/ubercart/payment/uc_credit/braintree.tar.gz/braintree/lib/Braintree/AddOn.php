<?php
class Braintree_AddOn extends Braintree_Modification
{
}
