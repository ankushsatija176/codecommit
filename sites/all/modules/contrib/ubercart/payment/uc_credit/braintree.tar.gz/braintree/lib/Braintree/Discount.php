<?php
class Braintree_Discount extends Braintree_Modification
{
}
